valor_produto=float(input('Digite o valor do produto: '))
valor_desconto=int(input('Digite o valor do desconto: '))
print(valor_produto-(valor_produto*valor_desconto/100))
