fahrenheit=float
celsius=int(input('Digite a temperatura: '))
print(((celsius*9)/5)+32)


