valor_divida=float(input('Digite o valor ser pago: '))
valor_sobra=float
print(valor_divida//50)
print(valor_divida%50)