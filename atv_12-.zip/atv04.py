valor_x=float(input('digite o valor X: '))
valor_y=float(input('digite o valor Y: '))
var1=valor_x
var2=valor_y
valor_x=var2
valor_y=var1

print(valor_x) 
print(valor_y)